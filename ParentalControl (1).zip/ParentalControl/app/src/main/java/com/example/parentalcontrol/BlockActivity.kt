package com.example.parentalcontrol

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.*

class BlockActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pkg = intent.getStringExtra("pkg") ?: ""
        val reason = intent.getStringExtra("reason")
        val prefs = Prefs(this)
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) { pkg }

        val msg = if (reason == "limit")
            "Дневной лимит для «$label» исчерпан."
        else
            "Приложение «$label» заблокировано родителем."

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setBackgroundColor(Color.WHITE)
        }
        root.addView(TextView(this).apply { text = msg; textSize = 20f; gravity = Gravity.CENTER })
        root.addView(Button(this).apply {
            text = "На главный экран"
            setOnClickListener { goHome() }
        })
        val pin = EditText(this).apply {
            hint = "PIN родителя"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        root.addView(pin)
        root.addView(Button(this).apply {
            text = "Разрешить на 15 минут"
            setOnClickListener {
                if (prefs.checkPin(pin.text.toString())) {
                    prefs.grantUnlock(pkg, 15)
                    finish()
                } else {
                    Toast.makeText(this@BlockActivity, "Неверный PIN", Toast.LENGTH_SHORT).show()
                }
            }
        })
        setContentView(root)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() = goHome()

    private fun goHome() {
        startActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        finish()
    }
}
