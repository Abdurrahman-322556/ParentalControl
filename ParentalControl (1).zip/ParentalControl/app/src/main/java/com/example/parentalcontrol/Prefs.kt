package com.example.parentalcontrol

import android.content.Context
import java.security.MessageDigest
import java.util.UUID

/** Хранилище настроек: PIN (хеш с солью), заблокированные приложения, лимиты, временные разблокировки. */
class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("pc", Context.MODE_PRIVATE)

    private fun hash(pin: String, salt: String): String =
        MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray())
            .joinToString("") { "%02x".format(it) }

    fun hasPin() = sp.getString("pin_hash", null) != null

    fun setPin(pin: String) {
        val salt = UUID.randomUUID().toString()
        sp.edit().putString("salt", salt).putString("pin_hash", hash(pin, salt)).apply()
    }

    fun checkPin(pin: String): Boolean {
        val salt = sp.getString("salt", null) ?: return false
        return hash(pin, salt) == sp.getString("pin_hash", null)
    }

    fun blocked(): Set<String> = sp.getStringSet("blocked", emptySet())!!.toSet()

    fun setBlocked(pkg: String, value: Boolean) {
        val s = blocked().toMutableSet()
        if (value) s.add(pkg) else s.remove(pkg)
        sp.edit().putStringSet("blocked", s).apply()
    }

    /** Дневной лимит в минутах; 0 — без лимита. */
    fun limit(pkg: String): Int = sp.getInt("limit_$pkg", 0)
    fun setLimit(pkg: String, minutes: Int) = sp.edit().putInt("limit_$pkg", minutes).apply()

    fun unlockUntil(pkg: String): Long = sp.getLong("unlock_$pkg", 0L)
    fun grantUnlock(pkg: String, minutes: Int) =
        sp.edit().putLong("unlock_$pkg", System.currentTimeMillis() + minutes * 60_000L).apply()

    var monitoring: Boolean
        get() = sp.getBoolean("monitoring", false)
        set(v) = sp.edit().putBoolean("monitoring", v).apply()
}
