package com.example.parentalcontrol

import android.Manifest
import android.app.Activity
import android.app.AppOpsManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.widget.*

class MainActivity : Activity() {
    private lateinit var prefs: Prefs
    private var authed = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        showAuth()
    }

    override fun onResume() {
        super.onResume()
        if (authed) showMain()
    }

    private fun showAuth() {
        val first = !prefs.hasPin()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(48), dp(24), dp(24))
        }
        root.addView(TextView(this).apply {
            text = if (first) "Придумайте PIN родителя (4–8 цифр)" else "Введите PIN родителя"
            textSize = 20f
        })
        val et = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        root.addView(et)
        root.addView(Button(this).apply {
            text = if (first) "Сохранить" else "Войти"
            setOnClickListener {
                val pin = et.text.toString()
                if (first) {
                    if (pin.length in 4..8) { prefs.setPin(pin); authed = true; showMain() }
                    else toast("PIN должен быть от 4 до 8 цифр")
                } else {
                    if (prefs.checkPin(pin)) { authed = true; showMain() } else toast("Неверный PIN")
                }
            }
        })
        setContentView(root)
    }

    private fun hasUsageAccess(): Boolean {
        val ops = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        return ops.unsafeCheckOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName
        ) == AppOpsManager.MODE_ALLOWED
    }

    private fun showMain() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(32), dp(16), dp(16))
        }
        val scroll = ScrollView(this).apply { addView(root) }

        root.addView(TextView(this).apply { text = "Родительский контроль"; textSize = 22f })

        val usageOk = hasUsageAccess()
        val overlayOk = Settings.canDrawOverlays(this)
        root.addView(TextView(this).apply {
            text = "Доступ к статистике: ${if (usageOk) "✔" else "✘"}\n" +
                "Показ поверх окон: ${if (overlayOk) "✔" else "✘"}"
        })
        if (!usageOk) root.addView(Button(this).apply {
            text = "Выдать доступ к статистике использования"
            setOnClickListener { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        })
        if (!overlayOk) root.addView(Button(this).apply {
            text = "Разрешить показ поверх других окон"
            setOnClickListener {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            }
        })
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        root.addView(Switch(this).apply {
            text = "Контроль включён"
            isChecked = prefs.monitoring
            setOnCheckedChangeListener { _, on ->
                prefs.monitoring = on
                val i = Intent(this@MainActivity, MonitorService::class.java)
                if (on) startForegroundService(i) else stopService(i)
            }
        })

        root.addView(TextView(this).apply {
            text = "\nПриложения: отметьте для блокировки или задайте лимит (мин/день)"
        })

        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .distinctBy { it.first }
            .filter { it.first != packageName }
            .sortedBy { it.second.lowercase() }

        for ((pkg, label) in apps) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(CheckBox(this).apply {
                text = label
                isChecked = pkg in prefs.blocked()
                setOnCheckedChangeListener { _, c -> prefs.setBlocked(pkg, c) }
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(EditText(this).apply {
                hint = "мин"
                inputType = InputType.TYPE_CLASS_NUMBER
                val l = prefs.limit(pkg)
                if (l > 0) setText(l.toString())
                addTextChangedListener(object : TextWatcher {
                    override fun afterTextChanged(s: Editable?) {
                        prefs.setLimit(pkg, s?.toString()?.toIntOrNull() ?: 0)
                    }
                    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                })
            }, LinearLayout.LayoutParams(dp(80), LinearLayout.LayoutParams.WRAP_CONTENT))
            root.addView(row)
        }
        setContentView(scroll)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
